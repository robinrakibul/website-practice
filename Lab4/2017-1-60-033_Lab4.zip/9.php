<html>
<body>

<form method="post">
  <label for="input">Input = </label>
  <br>
  <input type="number" id="input" name="input"><br>
  <input type="submit" name="submit" value="submit">
</form>


<?php

 if(isset ($_POST['submit'])){
     $n=$_POST['input'];
     x($n);
 }

function x($n)
{
    for($i=0;$i<$n;$i++)
    {
        for($j=0;$j<$n-$i;$j++)
        {
            echo"&nbsp&nbsp&nbsp";
        }

        for($j=-$i;$j<=$i;$j++)
        {
            if($j==0)
            {
                continue;
            }
            elseif($j==1)
            {
                continue;
            }
            echo "&nbsp".abs($j);
        }

        echo "<br>";

    }
}

?>

</body>
</html>
