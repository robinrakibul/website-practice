<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color:red;}
</style>
</head>
<body>  




<h2>Change Password</h2>

<form method="post">  
  

  Current Password:<br><input type="password" name="password">
 
  <br>
  New Password:<br><input type="password" name="cpassword">
  
  <br>
  Retype New Password:<br><input type="password" name="cpassword">

  <hr>
  <input type="submit" name="Change" value="Change" onclick="profile.php">
  <input type="button" value="Login" onclick="profile.php">
</form>
