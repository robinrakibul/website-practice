<?php
   include('session.php');
?>
<html">
   <body>
      <h1>Welcome to profile <?php echo $login_session."!"; ?></h1> 
      <h3><a href = "logout.php">Logout</a></h3>
   </body>
   
</html>